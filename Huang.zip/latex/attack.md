## Abstract

Nowadays, recommendation systems have become an essential component of e-commerce and content platforms. These systems are designed to capture users' product preferences through their historical interaction records. However, recent studies have shown that deep learning-based models are generally susceptible to adversarial examples, which can lead to unexpected performance of the model. This vulnerability also applies to recommender systems. Furthermore, a significant feature of recommendation system datasets is their natural bipartite graph structure consisting of two types of nodes: users and products; their interactions can be regarded as edges. Consequently, many researchers have employed graph neural networks to perform recommendation system tasks. In this study, we approach the problem of recommendation system attacks from a graph perspective by modeling it as a graph node injection problem where fake interaction records can be considered link prediction tasks. Our proposed approaches outperform existing ones in attacking performance on three real-world datasets even under strict conditions that permit only one node injection into the graph.

## 1. Introduction

With the rapid development of information technology today, information overload has become a problem that we must face. Fortunately, the emergence of recommendation systems has solved this problem. These systems have been widely used on many e-commerce platforms (e.g., Amazon, Alibaba) and content-providing platforms (e.g., Tik-Tok, Youtube), generating massive revenue.

However, due to the vulnerability of recommendation systems and other deep models to adversarial samples, many attackers try to attack the recommendation model for economic purposes. Many works have successfully demonstrated its powerful attack performance [work list]. An attacker can inject a series of well-designed fake profiles to easily deceive the recommender system and make an attacker-special prediction. Therefore, it is essential for us to study data poisoning attacks on recommender systems, which will reveal critical insights and strategies for developing effective defense methods.
	
In normal scenarios, although good performance has been achieved, almost all of these works have overlooked an inherent characteristic of recommender system datasets: the natural bipartite graph. Recommender system datasets generally have two types of nodes (e.g., user nodes, item nodes), and the interactions between nodes can be regarded as edges between the two types of nodes. If we consider the dataset as a graph, we can naturally revisit the recommender system as a graph node injection problem. There is no doubt that the structural information in the data graph can provide more attack knowledge to the attack model. However, current attack methods have not taken this into account. They focus on the profiles of a type of nodes while ignoring the hidden information between nodes. Therefore, if we consider the problem of recommended attack from a graph perspective, we can inject some nodes into the dataset of the recommendation system as well-designed fake users. The next task is to predict the links among nodes and design a reasonable loss function to guide the model to achieve our goal. At the same time, inspired by a recent article on graph neural network single-node injection attacks [work], we decided to greatly limit the attack scenarios of the model. We explore the performance of the model in the limit case of only one node injection. Additionally, when we greatly limit attack scenarios, we gain a new advantage: strong concealment ability. Because we only inject one node, it makes defense against attacks seem impossible.
In this paper, our focus is mainly on single node attacks. That is to say, the attack size will be set to just one. We try to explore the strongest attack performance under the greatest concealment where the attack goal is  to promote a target item, i.e. making the recommender system recommender the target to as many users as possible .In graph setting, our main idea is to make the attribute of the target item receive the propagation information on the graph, generate the node attribute as the user embedding, and then use the user embedding to guide the generation of edges (which can be regarded as the subgraph generation task). Additionally, there is a lot of information hidden in the node profile information, which we use as the initial node embedding and propagate in mapping and transformation. We believe that the final generated node contains the interaction information and topology information of the dataset, which will be more conducive to our attacks. Meanwhile, based on the assumption that the model with greater influence will guide the prediction of the network more, we adopted the idea of TrialAttack. Add the influence module to our model to guide the generation of more influential fake attributes, and in the following subgraphs, mislead the model's predictions more.
In summary, the main contributions of our work are as follows.

+ Reconsidering the formulation of the dataset of a recommender as a graph, which can maximize the usage of information in the dataset, including structured and topological information.
+ Designing a novel method of attacking recommender systems by injecting fake nodes in the dataset graph. At the same time, we set the attack size to only one and proved its feasibility.
+ Conducting extensive experiments to demonstrate the attack performance which is comparable work on real-world datasets and the generated fake users are difficult to be detected.

## 2. Related Work

Since the model based on deep learning was found to be vulnerable to confrontation samples, the research on the robustness of the model has been endless. People have successfully implemented attacks on recommendation systems, CNN models, GNN, and more recently. At the same time people also put forward many effective defensive measures.

**Poisoning Attack on RS** : 

A data poisoning attack is mainly carried out by injecting well-designed fake profiles into the recommender system's dataset to pollute the recommender system in order to change the recommended list for users. It was first proposed in a heuristics-driven way without optimization. In an average attack, the starting point is that similar users will have similar item preferences, making the damage of the attack not satisfactory.

Recently shilling attack generate profiles by optimization where most of the approaches rely on deep models. Yang et al.[] generate attacks by injecting fake co-visitaions to the recommenders and optimized in a linear combination. Tang et al.[] demenstrate the attacks by injecting learned fake profiles locally by the poisoners with their own models can be optimized precisely and lead to huge damage for the recommenders. Chen et al.[] generate diversified fake users by "augment" templates which are selected from existing real users to capture the hidden-connection between users and items with GAN. Wu et al.[] adopted the thought of attacking with a surrogate, that is, the influence. Under the idea that users with greater influence can produce greater attack effects, the influence module not only plays the role of evaluating the attack effect in training, but also guides the training of generator and discriminator.What' more, there are also works for graph based-recommender stems, like[]. However, none of them considered the dataset as a graph so that the more information will be adopted by this view.

**Adversarial Attacks on GNN** :

Recently more and more attention has been paid to adversarial attacks on graphs. Early work mainly try to perturb the graph by edge flipping[RL-S2V], label flipping[Adversarial Label-Flipping Attack and Defense for Graph Neural Networks], or other optimization techniques[]. But in the real world those are not realistic. The graph is usually unable to change the original structure (like dropping or flipping).

Node injecting seems to be a more realistic method. Sun et al.[NIPA] tried to sequentially modity the adversarial information of injected nodes by reinforcement learning; Tao et al.[GNIA] explored an extremely limited scenario that only permits single node to attak a graph; Tao et al.[CANA], on the basis of the previous work GNIA, it continued to explore the issue of concealment. Basically, the idea of all work is to first generate the attributes of fake nodes, and then generate the edges connected to fake nodes, or in the reverse order, to reach the target of the attack graph. We adopted this idea and applied it to our recommender system attack.

## 3.  Preliminaires

This section introduces GNN and other nerual network method we haved used in our work.

#### Graph nerual network

CNN is proficient in many fields such as image recognition. However, there are many non-Euclidean data in our lives such as social relations, chemical molecular structure and user commodity interaction records that cannot be processed by CNN since they are not Euclidean data. Graph neural network (GNN) is a type of artificial neural network that can process data represented as graphs. GNN has developed from frequency domain to spatial domain and to current processing mode based on message aggregation.

Given a graph G with $G=(V,E,X)$, where $V$ is the set of $|V|=N$ nodes , $E\subseteq V\times V$ is the set of $|E|$ edges and $X\in \mathbb{R}^{N\times d}$ is the attribute matrix with 𝑑-dimensional features. The graph structure can be denoted as adjacent matrix $A\subseteq \{0, 1\}^{N\times N}$, where $a_{ij}$ equals to 1 when there is an edge between node $v_i$ and $v_j$ or equals to 0 otherwise.
	
Typically a layer of GNN plays a role of node aggregation and the the message will be transformed to next layer as new node attribute. For layer layer $i$, it can be formulated as:
$$
X^i_{in}=f^{i-1}_{trans}(X^{i-1}_{out}); X^i_{out}=f^i_{agg}(X^i_{in})\tag{1}
$$
For example, the graph convolution layer of GCN[Kipf and Welling, 2016] is described as $H^{(l+1)}=f^{(l)}_{GCL}(\hat A, H^{(l)},W^{(l)})\sigma(\hat AH^{(l)}W^{(l)})$, where $\hat A$ denotes the normalized adjacency matrix with self-loop, $\sigma(\cdot)$ denotes the non-linearity function, and $W^{(l)}$ and $H^{(l)}$is the learnable parameters and node representations at lth layer respectively. Normally, at $K$-th layer, with the last dimension of $W_{(K)}$ and $\sigma(\cdot)$ set to $C$ and softmax respectively for node classification task, the loss for node $v_i$ is formulated as:
$$
\mathcal{L}(v_i,G,y_i)=CrossEntropy(f^{(K)}_{GCL}(\hat A, H^{(K)},W^{(K)})x_i, y_i)\tag{2}
$$
where $y_i$ is the label of node $v_i$.

**Masked Language Model**

After BERT (Bidirectional Encoder Representations from Transformers) was recently proposed as an alternative to Word2Vec, it has greatly improved the accuracy in 11 directions in the NLP field. This can be said to be the best breakthrough technology for self-residual networks in recent years. One of the most important points is the use of pre-training objective such as Mask Language Model (MLM) inspired by the Cloze task (Taylor, 1953). The goal of masked language model training is to correctly predict the masked token id through the context by randomly masking the original input words. Unlike left-to-right language model pre-training, the MLM objective enables the representation to fuse the left and right context, which allows us to pretrain a deep bidirectional Transformer. We adopt this idea by masking some nodes in the original graph and reconstructing them, hoping to get fake embeddings we never saw before while at the same time generating embeddings that contain target node and its neighborhood information.

### Problem Definition

*A. Threat Model*

**Attack Goal**

The attack goals of the malicious model can be roughly divided into two categories: promotion attack and nuke attack. In this paper, we consider our goal to be promoting a target item's recommended order in a user's recommended item list. At the same time, we aim to make the target item appear in as many users' top-K recommended lists as possible while retaining the recommender's performance. Our proposed method can efficiently perform attacks under extremely restricted conditions.

**Attack Knowledge**

We assume that the attacker can access the full dataset used to train the target (victim) recommender model. This is a reasonable assumption because they are all online and easy to capture (like Amazon purchase records and Twitter). Additionally, the attacker has full knowledge of the surrogate model, including its algorithm and parameters. The attacker can generate fake profiles from surrogate models to attack victim models about which they have little knowledge. With these poison fake profiles, they hope that the victim models can be misled by the generated users and make a prediction that satisfies the attacker's intent.

**Attack Capabilities**

Usually, when more fake users are allowed to be injected, a more powerful attack effect is generated. However, more fake users will also expose injection behavior more. Therefore, we must limit the number of fake users that can be injected to $\Delta$. Although we only inject one fake user, in order to better validate the model, we will also discuss the scenario of multi user injection. In addition, we will strictly limit the number of products that each fake user can interact with, budget to $b$.

*B. Bi-level optimization based attacks*

Most of the current work is based on a bi-level optimization problem of maximizing attack performance given a well-trained recommender system on polluted datasets.
$$
\underset{X'}{max}\mathcal{L}_{atk}(X,\theta_R),\tag{5}
$$
subject to
$$
\theta_R=\underset{\theta_R}{argmin}(\mathcal{L}_{train}(X,\theta_R)+\mathcal{L}_{train}(X', \theta_R))\tag{6}
$$
where $X\in \mathbb{R}^{n\times m}$ is the clean dataset,  which means the ratings,  $n$ users give to $m$ items. Besides, $r_{ij}=X_{ij}$ is the rating user $i$ give to item $j$ . $X'\in \mathbb{R}^{n'\times m}$ is the generated fake data. Of course, in our setting, $n'=1$. And $\theta_R$ stands for the parameters of well-trained recommender. In order to obtain the largest damage performance, we need to maximize the objective function of attack. Different adversarial objectives can lead to different purposes. In promotion target items setting, the loss function can be:
$$
\mathcal{L}_{atk}(X, \theta_R)=-\underset{i\in \mathcal{U}}{\sum}log(\frac{exp(r_{it})}{\sum_{j\in\mathcal{I}}exp(r_{ij})})\tag{7}
$$
where $t$ is the target item, $\mathcal{U}$ means the user set, $\mathcal{I}$ means the item set. Minimizing the loss function will lead the model predict  the ratings of target item $t$  in normal users higher and higher, and achieve our goal as a result.

## 4. Method

### **4.1 Overview**

In this paper, we proposed a novel idea of an adversarial learning by considering the dataset as graph which transfer this work to generate fake nodes on graph to achieve malicious goal.  Inspired by GNIA, the proposed model will be consist of attribute generation and subgraph generation. The specific framework is shown in Fig.1 .

+ **Attribute generation:** Given a dataset of rating matrix $M\in \mathcal{R}^\mathcal{|U|\times|V|}$ in RS, where $\mathcal{U}$ is the set of real users and $\mathcal{V}$ is the set of item universe, and its feature matrix $X\in \mathcal{R}^{(\mathcal{(|V|+|U|)}\times d_i}$, where $d_i$ is the dimension of feature vector, attribute generation is delicated to generating fake users' embedding with strong toxicity and can offer the need target item information to the subgraph generation module.
+ **subgraph generation:** We consider the procedure of linking fake user nodes and other item nodes as a subgraph generation task, which can lead to more efficiency,  the subgraph generation module is used to generate malicious edges between malicious nodes and normal nodes in order to spread its misleading information to the required candidate items, so that the subgraph generated can guarantee to meet the intention of attacker.

### **4.2 Attribute Generation**

To ensure that the fake embedding generated at the end of the attribute generation stage includes the original information of the node during the information transmission process, we use the node's profiles feature as the initial embedding. Previous research[] summarized different metrics to characterize the features extracted from profiles, at the same time, we consider the graph as isomorphic so the features will be calculated in a same way not matter user nodes and item nodes. We list 3 of them as examples.

#### **4.2.1 Employed features**

**Rating Deviation from Mean Agreement(RDMA):** RDMA is a metric for detecting attackers in recommender systems. It measures the average deviation of a user's ratings from the mean agreement for a set of target items. The inverse of the numer of ratings for each item is used as a weight to account for the fact that items with more ratings are more likely to be rated accurately, and RDMA is calculated as follows:
$$
RDMA_u=\frac{\sum^{N_u}_{i=0}\frac{|r_{u,i}-\bar {r_i}|}{NR_i}}{N_u}
$$
where $N_u$ is the number of ratings that user $u$ has rated and $NR_i$ is the number of ratings provided for item $i$. And $r_{u,i}$ denotes the ratings given by user $u$ to item $i$, and $\bar {r_i}$ denote the mean rating of item $i$ across all users.

**Length Variance(LengthVar):** LengthVar measures the variance of the number of ratings in a user's profile. Attacker profiles typically have a higher variance in the number of ratings than genuine profiles, as attackers are more likely to create profiles with a small number of ratings or a large number of ratings. LengthVar is calculated as follows:
$$
LengthVar_u=\frac{n_u-\bar n}{\sum_{k\in U}(n_k-n)^2}
$$
where $n_u$ is the total number of ratings in the system for user u. $U$ is the total number of users in the system. $\bar n$ is the average length of a profile in the system.

**Filler Mean Variance(FMV):** FMV measures the variance of a user's rating in a hypothesized filler partition from the mean rating for each of the items. The hypothesized filler partition is a set of items that are likely to be rated by attackers in an attempt to increase the size of their user profiles. FMV is calculated as follow:
$$
FMV_u=\frac {1}{U_{u^{F_m}}} \underset{i\in U_{u^{F_m}}}{\sum}(r_{u,i}-\bar {r_i})^2
$$
where $U_{u^{F_m}}$ is the partition of the profile of user $u$ hypothesized to be the set of filler items $F$ by model $m$. $|U_{u^{F_m}}|$ is the number of items in the hypothesized filler partition of profile $P_u$ the mean rating for each of items.

When all the features are available, we directly use the feature results as initial embeddings for all nodes. Then they are first processed via a linear project layer to get fixed size embedding matrix $X_{emb}\in \mathcal{R}^{d_f}$, i.e. $X_{emb}=W_2\sigma(W_1X)$, where $X$ is the initial embeddings calculated by profile features. The $X_{emu}$ will be used to generate fake embeddings.

#### **4.2.2 Generate attribute with attack information**

The key point in node injection is to propagate malicious information to proper nodes through  message passing. This part we will adopt an encoder-decoder framework and an influence module to obtain the topology information of target item node and try to offer more misleading information in message aggregation for the next subgraph generation stage. 

As mentioned in [], our model employs a modified GC-MC[] graph aggregator to encode structural information. The GC-MC neural network is a graph-based auto-encoder framework for matrix completion that produces latent features of user and item nodes through a form of message passing on the bipartite interaction graph. The auto-encoder uses two multi-link graph convolution layers to aggregate user features and item features. The ratings are estimated by predicting the edge labels The message from items to user $u$ are calculated as 
$$
y^r_u=\underset{v\in \mathcal{N}_r (u)}{\sum}\frac 1 {c_{uv}}W^r_aX_v,\\
h_u = MLP(\underset{r=1}{\overset {R}{\sum}}y^r_{u})\tag{8}
$$
where $y^r_u$ represent the aggregated message of its neighbor with link type $r$, $\mathcal{N}_r(u)$ is the neighbors with link type $r$, and $c_{uv}=\sqrt {|\mathcal{N}_r(u)||\mathcal{N}_r(v)|}$ is a normalized constant. $X_v\in \mathcal{R}^{d_f}$ is the projected embedding of item $v$.  When all link-specific aggregate messages are ready, all the message will be summed up and  pass the output to a MLP layer with two layers of non-linear function $\alpha(\cdot)$  and a layer of linear network to obtain the updated node representation $h_u$ for user $u$. And next the GC-MC model will repeat on item node $v$, but we don't use the representation to predict the rating score between user $u$ and item $v$, cause it's not a recommender task. User nodes and item nodes will both be updated by the above procedure. But in order to generate the unseen fake user node, we take an approach of randomly masking some original nodes and reconstruct them in the decoder phase. And as a result, we can generate fake user node by masking some of carefully selected nodes through reconstruction. We use a two-layer MLP as a decoder, i.e. $\hat X=W_4\sigma(W_3 h)$, where the dimension during transformation keeps unchanged.

By this encoder-decoder frame work we hope to obtain fake node embedding contains sufficient attack information about the target item nodes. And its a general graph neural network, which mean other formats of GNN can also be adopted, e.g. GCN[], GraphSage[] and GAT[].
	
In order to make the fake embedding contain as much information as possible. We adopted influence module[] to help fake embeddings achieve the most malicious based on the assumption that the node with the largest influence has the most destructive power. As mentioned in [], the impact of the weight of a certain training sample on the loss of the test sample.:
$$
I_{up,loss}(z, z_{test})=-\nabla_{\theta}L(z_{test}, \hat \theta)^TH^{-1}_{\hat \theta}\nabla_{\theta}L(z,\hat \theta)
$$
There are two difficulties in calculating the empirical risk. The first is to calculate the Hessian matrix of empirical risk $H^{-1}_{\hat \theta}$. The computational cost is too high for current neural networks. The second is that in practice, we want to calculate the influence function for each sample in the training set. The author provides two calculation methods: conjugate gradient and stochastic estimation, both based on Hessian-vector products (HVP), which do not require explicit calculation of $H^{-1}_{\hat \theta}$. Instead, the overall calculation is $s_{test}=H^{-1}_{\theta}\nabla_{\theta}L(z_test, \hat\theta)$. The impact function is $I_{up,loss}(z, z_{test})=-s_{test}\cdot \nabla_{\theta}L(z,\hat \theta)$. We do not calculate node influence by the formula each time, instead we employ a neuraul network to simulated calculation process, specifically we adopt the network to predict each node's influence with the surprised learning by constructing dataset from real users. The network try to minimize the gap between predicted influnce and real influence.
$$
min\mathcal{L}^I = MSE(I(u_i),\ f_{inp}(u_I))\tag{10}
$$

where $f_{inp}$ is the neural network for simulation.

### **4.3 Subgraph Generation**

At this phase, the generated subgraph is dedicated to spreading malicious information by its attribute, which contains rich attack information to the required candidate nodes. Here, the candidate nodes are limited within the target nodes and their first and second-order neighbors,  making the poison message can spread to candidate nodes. At the same time, we limit the number of connected edges to budget $\Delta$ for the cause of avoiding being detected. And we calculate the score between fake nodes and candidate nodes, which the scores means the the impact of connecting certain candidate nodes on attack performance.

We use malicious fake embeddings to guide subgraph generation. Sepcifically, we use the representation of fake nodes $r_f$ and representation of candidate nodes $r_c$ to obtain the edge scores and link fake nodes with top $\Delta$ largest nodes as a generated graph. What's more, the fake representation and candidate node representations are being projected by a single layer of linear network in order to project to the same dimension space. i.e $h_f=W_{pro}r_f,\ h_c=W_{pro}r_c$. Then we will calculate the scores as follow:
$$
\hat A(h_f, h_c)=s(h_f, h_c)\\s = \frac{h_f*h_c}{||h_f||_2*||h_c||_2}
$$

where $W_{pro}$ are trainable parameters .

To tackle the discreteness of the network structure, we adopt Gumbel-Top-k technique to the solve the optimization problem. Gumbel-Top-k is a method for sampling sequences without replacement. It is an extension of the Gumbel-Max trick for sampling from a categorical distribution. The Gumbel-Max trick is a method for sampling from a categorical distribution by adding independent and identically distributed (i.i.d.) Gumbel noise to the log-probabilities of each category and selecting the category with the highest sum of log-probability and Gumbel noise. The Gumbel-Top-k trick extends this method to sample k elements without replacement. For $\varepsilon \sim\mathcal{N}(\varepsilon;0,1)$, gumbel-Softmax is :
$$
softmax((log\ p_i-log(-log\varepsilon_i))/\tau)^k_{i=1},\ \ \varepsilon\sim U[0,1]
$$
Among them, parameters $\tau>0$, which is called the annealing parameter, and the smaller it is, the closer the output result is to the one hot form (but at the same time, the more severe the gradient disappears).Gumbel-Softmax brings exploration to the edge selection through Gumbel distribution $G_i$ . To encourage exploring, we further user $\epsilon$ to control the strength of exploration:
$$
Gumbel-Softmax(z,\epsilon)_i=\frac{exp(\frac{z_i+\epsilon G_i}{\tau})}{\sum^n_{j=1}exp(\frac{z_i+\epsilon G_i}{\tau})}
$$

Gumbel-Top-k function $G^e$ is:
$$
G^e(z)=\overset{k}{\underset{j=1}{\sum}}Gumbel-Softmax(z\odot mask_j,\epsilon)
$$
where $𝑘$ is the budget of edges (discrete attributes), $𝑚𝑎𝑠𝑘_𝑗$ filters the selected edges/attributes to ensure they will not be selected again. Note that the obtained vector is sharp but not completely discrete, which benefits training. In the test phase, we discretize the vector compulsorily to obtain discrete edges. And we do the same for discrete attributes.

### **4.4 Optimization**

After subgraph generation, we inject the malicious graph into the original clean dataset graph $G$ to obtain perturbed dataset graph $G'$. The we feed the polluted dataset to retrain the victim recommender and compute the attack loss $\mathcal{L}_{atk}$:
$$
\mathcal{L}_{atk}(X, \theta_R)=- \underset{i\in \mathcal{U}}{\sum}log(\frac{exp(r_{it})}{\sum_{j\in\mathcal{I}}exp(r_{ij})}) + \underset{u,i}{\sum}(r_{ui}-\hat r_{ui})
$$
Attack loss $\mathcal{L}_{atk}$ is used to guide the training process. We iteratively optimize the attack loss by gradient descent until convergence. 

## 5. Experiment

### 5.1 Experimental Settings

**5.1.1 Dataset** In this paper, in order to illustrate the wide adaptability of our method we adopted three real-world recommendation datasets to evaluate the effectiveness of the proposed attack approaches.

+ **FilmTrust** is a small dataset crawled from the entire FilmTrust website in June 2011. It contains 35,497 item ratings and 1,853 directed trust ratings [1](https://guoguibing.github.io/librec/datasets.html). The dataset is used for rating prediction and trust prediction tasks in recommender systems research [2](https://www.nature.com/articles/s41598-020-70350-1)
+ **HetRec Delicious Bookmarks**  is a dataset that contains social networking, tagging, and resource consuming (Web page bookmarking and music artist listening) information from sets of around 2,000 users.
+ **HetRec Last.FM** dataset contains information about user listening history, demographic details, and music artist details .

    The statistics of datasets are shown in Table 1.

<center> Table 1: Statistics of the datasets

| Dataset          | Users | Items | Interactions | Sparsity |
| ---------------- | ----- | ----- | ------------ | -------- |
| FilmTrust        | 780   | 721   | 28799        | 94.88%   |
| HetRec-delicious | 1867  | 69223 | 437593       | 99.66%   |
| HetRec-last.fm   | 1892  | 12523 | 186479       | 99.21%   |

**5.1.2 Baseline Methods** We compare our work with the classic shilling attack and the state-of-the-art attacks based on neural network, including Random Attack, Bandwagon Attack and Segment Attack and TrialAttack, AUS, LegUP. And we use the default setting to obtain the attack performance of baselines.

**5.1.3 Evaluation Metric** We adopt HitRatio(HR) and Normalized Discounted Cumulative Gain(NDCG) as our evaluation metric. HitRatio is the fraction of users for whom the recommended items include at least one item that user interacted with. NDCG is a metric that takes into account the order of the recommendations. It is calculated by the first computing the cumulative gain for each item, which is the sum of the relevance scores of all items that are ranked before it. The two metric are formulated as follow:
$$
HR@k=\frac{n_{hit}}k\\NDCG@k=\frac{DCG@k}{IDCG@k}
$$
where $n_{hit}$ is the number of recommended items that are in the top-k items that the user interacted with, and DCG@k is the discounted cumulative gain at position k and IDCG@k is the ideal discounted cumulative gain at position $k$.

**5.1.4 Parameters setting** For our attack, we select LeakReLU as our non-linear activate function with the negative slope equals to 0.1. And during training we set the training epoch to 64, batch size to 32, embedding size to 64 and learning rate to 5e-4. In attribute generation we randomly mask 10% of nodes and try to recover, the candidate items are co-visited items for target item and random sampled popular items. We set the attack size to 50 when multi-users are injected. The source code of our method is available is in [https://github](https)

### 5.2 Attack performance

**5.2.1 Performance of single and multiple node injection**

We first attack under the limit conditions of a single node injection, and all baselines also perform the same operation. In such a situation, the attacker is only allowed to inject one node into the dataset, and the number of connected item nodes is allowed to be less than the budget, but the attack loss should be minimized as much as possible. Table 2 shows in detail the results of our method compared to the baseline model, and all the results of the out perform will be displayed in bold font.  The value on the left side of the slash represents the effect of single node injection, while the value on the right side represents the attack effect when injecting 50 fake users. It can be seen that when a single node is injected, our proposed method can significantly outperform the baseline model. When injecting 50 generated fake users, our method can still produce comparable results.

<table>
  <tr>
    <th rowspan='2', align='center'>Dataset</th>
    <th rowspan='2', align='center'>Victim Model</th>
    <th colspan='7', align='center'>Attack Method(HR@50)</th>
  </tr>
  <tr>
    <th>Random</th>
    <th>Segment</th>
    <th>AUSH</th>
    <th>TrialAttack</th>
    <th>Bandwagon</th>
    <th>LegUP</th>
    <th>ours</th>
  </tr>
  <tr>
  	<th align='center'>Automotive</th>
    <th align='center'>ItemCF<br>WMF<br>NGCF<br>VAE<br>temAE<br>NCF<br>LightGCN</th>
  </tr>
</table>

Table 2: Attack performance between single node attack and multi-nodes attack of different attack methods with different dataset against different victim models.

Additionally, we calculated the ration between single node attack performance and the best performance to show the posibility to attack the recommender system by only one node. Experienment study have shown that only inject one node is able to attack the recommender system, more fake data helps less that the one injected nodes. At the same time, we inject multiple node to show the full ability of our model. At some time our model can outperform that other state-of-art model, which demenstrate a comparable result.

### 5.3 Fake User Detection

**5.3.1 Attach Detection**

We apply an unsupervised attack detector [] on the fake user profiles generated by different attack models and report the accuracy  and recall in Table 3. Lower precision and recall indicate that the attack method is less perceptible. The results show that the fake users generated by our method are more difficult to detect compared to other methods, indicating that the fake users generated by our method are more covert.

**5.3.2 Fake User Distribution**

At this stage, we attempt to use t-SNE to visualize node distribution. We will directly map the generated fake user profiles and normal user profiles to two-dimensional space, attempting to distinguish between fake users and normal users.  The visualization results are shown in Figure 2. We visualized them on two datasets, HetRec delicious and HetRec Last.FM, respectively. The red nodes in the figure are the fake users generated in place.

Note that we do not visualize individual nodes because they are generally difficult to discover. We only visualize the situation of multi node injection.The results show that the generated fake users are difficult to distinguish from normal users, so our method can also generate hidden nodes when injecting multiple users.

## Conclusion

In this paper we explore an extremely limited situation of shilling attack that only inject one fake user to dataset, and we try to transform the shilling attack task to graph attack by reconsidering the dataset as a graph so that more attack information can be obtained to help attack the victim. With only injecting one node, our method shows counterpart performance compare to current attack works and so does to injecting fake users with curtain attack size. In the future, we will explore more about the single node to demenstrate the mechanism after the successful attack, and try to propose a way to defend our attack. 

## Reference
